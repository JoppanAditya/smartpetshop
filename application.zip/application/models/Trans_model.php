<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Trans_model extends CI_Model
{
    function getTransactions()
    {
        $this->db->select('transactions.*, user.fullname, address.name, address.phone, address.city, address.full_address, address.notes');
        $this->db->from('transactions');
        $this->db->join('user', 'transactions.user_id = user.user_id');
        $this->db->join('address', 'transactions.address_id = address.id');
        $this->db->order_by('date_created', 'desc');
        return $this->db->get()->result_array();
    }

    function getTransactionDetails($id)
    {
        return $this->db->get_where('transaction_details', ['transaction_id' => $id])->result_array();
    }

    function getTransById($id)
    {
        return $this->db->get_where('transactions', ['id' => $id])->row_array();
    }

    function getTransByUser($id)
    {
        $this->db->select('transactions.*, transaction_details.*, products.image, address.name, address.phone, address.city, address.full_address, address.notes');
        $this->db->from('transactions');
        $this->db->join('address', 'transactions.address_id = address.id');
        $this->db->join('transaction_details', 'transactions.id = transaction_details.transaction_id');
        $this->db->join('products', 'transaction_details.product_id = products.id');
        $this->db->where('transactions.user_id', $id);
        $this->db->order_by('transactions.date_created', 'desc');
        $this->db->group_by('transactions.id');
        return $this->db->get()->result_array();
    }

    function getTransByInvoice($invoice)
    {
        $trans = $this->db->get_where('transactions', ['invoice' => $invoice])->row_array();
        $trans_id = $trans['id'];

        $this->db->select('transactions.*, user.fullname, address.name, address.phone, address.city, address.full_address, address.notes');
        $this->db->from('transactions');
        $this->db->join('user', 'transactions.user_id = user.user_id');
        $this->db->join('address', 'transactions.address_id = address.id');
        $this->db->where('transactions.id', $trans_id);
        return $this->db->get()->row_array();
    }

    function updateStatus($id, $status)
    {
        $this->db->set('status', $status);
        $this->db->where('id', $id);
        return $this->db->update('transactions');
    }
}
